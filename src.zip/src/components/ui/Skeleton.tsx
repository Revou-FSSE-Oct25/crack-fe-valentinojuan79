import React from "react";
import { cn } from "@/lib/utils";

interface SkeletonProps { className?: string; }

export const Skeleton: React.FC<SkeletonProps> = ({ className }) => (
  <div className={cn("bg-gray-200 animate-pulse rounded", className)} />
);