import React from "react";
import { cn } from "@/lib/utils";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  fullWidth?: boolean;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, leftIcon, rightIcon, fullWidth, className, ...props }, ref) => (
    <div className={cn("flex flex-col gap-1.5", fullWidth && "w-full")}>
      {label && <label className="text-sm font-medium text-gray-700">{label}</label>}
      <div className="relative flex items-center">
        {leftIcon && (
          <div className="absolute left-3.5 text-gray-400 pointer-events-none flex items-center justify-center">
            {leftIcon}
          </div>
        )}
        <input
          ref={ref}
          className={cn(
            "w-full bg-white border rounded-xl text-sm transition-all duration-150 outline-none",
            "focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500",
            error ? "border-red-500" : "border-gray-200",
            leftIcon ? "pl-11" : "pl-4",
            rightIcon ? "pr-11" : "pr-4",
            "py-2.5",
            className
          )}
          {...props}
        />
        {rightIcon && (
          <div className="absolute right-3.5 text-gray-400 flex items-center justify-center">
            {rightIcon}
          </div>
        )}
      </div>
      {error && <p className="text-xs text-red-500 font-medium mt-0.5">{error}</p>}
    </div>
  )
);

Input.displayName = "Input";