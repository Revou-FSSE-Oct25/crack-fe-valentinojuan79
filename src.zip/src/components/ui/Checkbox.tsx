import React from "react";
import { cn } from "@/lib/utils";

interface CheckboxProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
}

export const Checkbox = React.forwardRef<HTMLInputElement, CheckboxProps>(
  ({ label, className, ...props }, ref) => (
    <label className="inline-flex items-center gap-2.5 cursor-pointer select-none group">
      <div className="relative flex items-center">
        <input
          ref={ref}
          type="checkbox"
          className={cn(
            "peer w-4 h-4 rounded-md border-gray-300 text-brand-500 focus:ring-brand-500 transition-all cursor-pointer",
            className
          )}
          {...props}
        />
      </div>
      {label && <span className="text-sm text-gray-600 leading-none group-hover:text-gray-900 transition-colors">{label}</span>}
    </label>
  )
);

Checkbox.displayName = "Checkbox";